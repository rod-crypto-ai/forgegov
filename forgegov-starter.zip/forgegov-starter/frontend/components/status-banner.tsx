"use client";

import { useEffect, useState } from "react";
import { API_BASE } from "@/lib/api";

type Status = { status?: string; detail?: string };

export function StatusBanner() {
  const [status, setStatus] = useState<Status>({});

  useEffect(() => {
    fetch(`${API_BASE}/health/`)
      .then((r) => r.json())
      .then((data) => setStatus(data))
      .catch(() => setStatus({ detail: "Backend is not running. Start Docker to connect live data." }));
  }, []);

  return status.status === "ok" ? (
    <div className="status-banner success">API connected</div>
  ) : (
    <div className="status-banner warning">{status.detail ?? "Checking API connection..."}</div>
  );
}
