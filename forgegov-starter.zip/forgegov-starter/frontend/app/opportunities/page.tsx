"use client";

import { FormEvent, useState } from "react";
import { ExternalLink, Search } from "lucide-react";
import { PageHeader } from "@/components/page-header";
import { API_BASE } from "@/lib/api";

type SamOpportunity = {
  noticeId?: string;
  title?: string;
  solicitationNumber?: string;
  fullParentPathName?: string;
  postedDate?: string;
  responseDeadLine?: string;
  uiLink?: string;
  type?: string;
};

export default function OpportunitiesPage() {
  const [query, setQuery] = useState("");
  const [rows, setRows] = useState<SamOpportunity[]>([]);
  const [loading, setLoading] = useState(false);
  const [message, setMessage] = useState("Enter a keyword to search SAM.gov through the ForgeGov backend.");

  async function submit(event: FormEvent) {
    event.preventDefault();
    setLoading(true);
    setMessage("");
    try {
      const response = await fetch(`${API_BASE}/live/sam/opportunities/?q=${encodeURIComponent(query)}&limit=25`);
      const data = await response.json();
      if (!response.ok) throw new Error(data.detail ?? "Search failed.");
      setRows(data.opportunities ?? []);
      setMessage(`${data.total_records ?? 0} matching SAM.gov records found.`);
    } catch (error) {
      setRows([]);
      setMessage(error instanceof Error ? error.message : "Search failed.");
    } finally {
      setLoading(false);
    }
  }

  return (
    <>
      <PageHeader eyebrow="Live government data" title="Opportunity search" description="Search current SAM.gov notices. Results are returned by the backend so credentials never have to be exposed in the browser." />
      <section className="panel">
        <form className="search-form" onSubmit={submit}>
          <div className="search-input"><Search size={20} /><input value={query} onChange={(e) => setQuery(e.target.value)} placeholder="Examples: vehicle maintenance, cybersecurity, janitorial" /></div>
          <button className="primary-button" disabled={loading}>{loading ? "Searching..." : "Search SAM.gov"}</button>
        </form>
        <p className="helper-text">{message}</p>
      </section>

      <section className="panel table-panel">
        <div className="panel-header"><div><span className="eyebrow">Results</span><h2>Federal opportunities</h2></div></div>
        {rows.length === 0 ? (
          <div className="empty-state"><Search size={28} /><strong>No results loaded</strong><p>Configure the SAM.gov API key and run a search. This page intentionally does not fabricate opportunity data.</p></div>
        ) : (
          <div className="table-wrap">
            <table>
              <thead><tr><th>Opportunity</th><th>Agency</th><th>Posted</th><th>Deadline</th><th>Source</th></tr></thead>
              <tbody>{rows.map((row, index) => (
                <tr key={row.noticeId ?? `${row.solicitationNumber}-${index}`}>
                  <td><strong>{row.title ?? "Untitled notice"}</strong><span>{row.solicitationNumber ?? row.type ?? ""}</span></td>
                  <td>{row.fullParentPathName ?? "—"}</td>
                  <td>{row.postedDate ?? "—"}</td>
                  <td>{row.responseDeadLine ?? "—"}</td>
                  <td>{row.uiLink ? <a href={row.uiLink} target="_blank" rel="noreferrer">SAM.gov <ExternalLink size={14} /></a> : "SAM.gov"}</td>
                </tr>
              ))}</tbody>
            </table>
          </div>
        )}
      </section>
    </>
  );
}
