# ForgeGov

ForgeGov is a government-contracting intelligence and capture-management platform built with Django, PostgreSQL, Redis, Celery, Next.js, and GitHub Actions.

This repository is the first working foundation. It includes:

- A responsive application shell based on the supplied navigation references.
- Django REST API with JWT authentication.
- Organization, opportunity, pipeline, task, and saved-search data models.
- SAM.gov opportunity search integration.
- USAspending API connectivity check.
- Functional dashboard, opportunity search, pipeline, team, and settings routes.
- PostgreSQL, Redis, Celery, Docker, and GitHub Actions configuration.

## Start locally with Docker

1. Copy the environment file:

   ```bash
   cp .env.example .env
   ```

2. Add a SAM.gov API key to `.env` if you want live SAM.gov opportunity search.

3. Start the stack:

   ```bash
   docker compose up --build
   ```

4. Open:

   - Web app: `http://localhost:3000`
   - API: `http://localhost:8000/api/`
   - Django admin: `http://localhost:8000/admin/`

5. Create an admin user:

   ```bash
   docker compose exec backend python manage.py createsuperuser
   ```

## Run without Docker

### Backend

```bash
cd backend
python -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
cp ../.env.example ../.env
python manage.py migrate
python manage.py runserver
```

### Frontend

```bash
cd frontend
npm install
npm run dev
```

## Important

This is an initial product foundation, not a finished GovTribe/HigherGov replacement. The next development milestone is persistent workspace onboarding, saved searches and alerts, production-grade SAM.gov ingestion, award ingestion, and authenticated capture workflows.

See `docs/ROADMAP.md` and `docs/ARCHITECTURE.md`.
