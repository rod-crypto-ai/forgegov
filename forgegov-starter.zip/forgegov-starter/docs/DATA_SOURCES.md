# Data Sources

## SAM.gov Opportunities API

Purpose: current federal contract opportunity notices and updates.

Implementation requirements:

- API key stored only in environment/secret storage.
- Pagination and rate-limit handling.
- Source notice ID and modified date used for idempotent upserts.
- Original source URL and retrieval timestamp retained.
- Attachments fetched only under permitted API behavior.

## USAspending API

Purpose: federal award, recipient, agency, and spending intelligence.

The initial connector checks API availability. Award ingestion is scheduled for a later milestone because the award model and aggregation strategy must be designed before loading a large dataset.

## Data integrity rules

- Never present predicted recompetes as official dates.
- Never silently merge organizations solely by similar names.
- Never overwrite user capture notes with refreshed source data.
- Display source and last-updated timestamps on government records.
