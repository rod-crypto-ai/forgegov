from django.urls import include, path
from rest_framework.routers import DefaultRouter
from .views import (
    OpportunityViewSet,
    OrganizationViewSet,
    PipelineItemViewSet,
    SavedSearchViewSet,
    TaskViewSet,
    health,
    integration_status,
    live_sam_search,
)

router = DefaultRouter()
router.register("organizations", OrganizationViewSet)
router.register("opportunities", OpportunityViewSet, basename="opportunity")
router.register("pipeline", PipelineItemViewSet)
router.register("tasks", TaskViewSet)
router.register("saved-searches", SavedSearchViewSet)

urlpatterns = [
    path("health/", health),
    path("integrations/status/", integration_status),
    path("live/sam/opportunities/", live_sam_search),
    path("", include(router.urls)),
]
