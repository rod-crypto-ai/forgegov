from celery import shared_task
from .integrations import usaspending_status


@shared_task

def check_external_integrations():
    return {"usaspending": usaspending_status()}
