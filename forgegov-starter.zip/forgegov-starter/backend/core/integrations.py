from datetime import date, timedelta
import requests
from django.conf import settings


class IntegrationError(RuntimeError):
    pass


def search_sam_opportunities(*, keyword: str = "", limit: int = 25, posted_from: str | None = None, posted_to: str | None = None):
    if not settings.SAM_GOV_API_KEY:
        raise IntegrationError("SAM_GOV_API_KEY is not configured.")

    today = date.today()
    params = {
        "api_key": settings.SAM_GOV_API_KEY,
        "limit": max(1, min(limit, 100)),
        "postedFrom": posted_from or (today - timedelta(days=30)).strftime("%m/%d/%Y"),
        "postedTo": posted_to or today.strftime("%m/%d/%Y"),
    }
    if keyword:
        params["q"] = keyword

    try:
        response = requests.get(settings.SAM_GOV_BASE_URL, params=params, timeout=20)
        response.raise_for_status()
    except requests.RequestException as exc:
        raise IntegrationError(f"SAM.gov request failed: {exc}") from exc

    payload = response.json()
    return {
        "total_records": payload.get("totalRecords", 0),
        "limit": payload.get("limit", params["limit"]),
        "offset": payload.get("offset", 0),
        "opportunities": payload.get("opportunitiesData", []),
    }


def usaspending_status():
    url = f"{settings.USASPENDING_BASE_URL.rstrip('/')}/api/v2/references/agency/"
    try:
        response = requests.get(url, timeout=15)
        return {
            "configured": True,
            "reachable": response.ok,
            "status_code": response.status_code,
        }
    except requests.RequestException as exc:
        return {"configured": True, "reachable": False, "error": str(exc)}
