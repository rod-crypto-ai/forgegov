from django.conf import settings
from django.db.models import Q
from rest_framework import status, viewsets
from rest_framework.decorators import api_view
from rest_framework.response import Response

from .integrations import IntegrationError, search_sam_opportunities, usaspending_status
from .models import Opportunity, Organization, PipelineItem, SavedSearch, Task
from .serializers import OpportunitySerializer, OrganizationSerializer, PipelineItemSerializer, SavedSearchSerializer, TaskSerializer


@api_view(["GET"])
def health(request):
    return Response({"status": "ok", "service": "forgegov-api"})


@api_view(["GET"])
def integration_status(request):
    return Response({
        "sam_gov": {"configured": bool(settings.SAM_GOV_API_KEY)},
        "usaspending": usaspending_status(),
    })


@api_view(["GET"])
def live_sam_search(request):
    try:
        data = search_sam_opportunities(
            keyword=request.query_params.get("q", ""),
            limit=int(request.query_params.get("limit", 25)),
            posted_from=request.query_params.get("posted_from"),
            posted_to=request.query_params.get("posted_to"),
        )
        return Response(data)
    except (IntegrationError, ValueError) as exc:
        return Response({"detail": str(exc)}, status=status.HTTP_400_BAD_REQUEST)


class OrganizationViewSet(viewsets.ModelViewSet):
    queryset = Organization.objects.all().order_by("name")
    serializer_class = OrganizationSerializer


class OpportunityViewSet(viewsets.ModelViewSet):
    serializer_class = OpportunitySerializer

    def get_queryset(self):
        queryset = Opportunity.objects.all()
        search = self.request.query_params.get("search")
        agency = self.request.query_params.get("agency")
        naics = self.request.query_params.get("naics")
        if search:
            queryset = queryset.filter(
                Q(title__icontains=search)
                | Q(description__icontains=search)
                | Q(solicitation_number__icontains=search)
            )
        if agency:
            queryset = queryset.filter(agency__icontains=agency)
        if naics:
            queryset = queryset.filter(naics_code=naics)
        return queryset


class PipelineItemViewSet(viewsets.ModelViewSet):
    queryset = PipelineItem.objects.select_related("opportunity", "organization", "owner").all()
    serializer_class = PipelineItemSerializer


class TaskViewSet(viewsets.ModelViewSet):
    queryset = Task.objects.select_related("organization", "pipeline_item", "assigned_to").all()
    serializer_class = TaskSerializer


class SavedSearchViewSet(viewsets.ModelViewSet):
    queryset = SavedSearch.objects.select_related("organization", "owner").all()
    serializer_class = SavedSearchSerializer
