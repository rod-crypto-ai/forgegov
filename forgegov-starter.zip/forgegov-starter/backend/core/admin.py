from django.contrib import admin
from .models import Membership, Opportunity, Organization, PipelineItem, SavedSearch, Task

admin.site.register(Organization)
admin.site.register(Membership)
admin.site.register(Opportunity)
admin.site.register(PipelineItem)
admin.site.register(Task)
admin.site.register(SavedSearch)
